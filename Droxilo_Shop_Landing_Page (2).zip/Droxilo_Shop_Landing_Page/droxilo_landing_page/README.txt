Droxilo Shop — Landing Page
============================

الملفات:
- index.html
- assets/logo.png
- assets/hoodie-front.jpg
- assets/back-print.png

قبل النشر:
1) افتح index.html.
2) ابحث عن:
   const WHATSAPP_NUMBER = "212600000000";
3) عوّض الرقم برقم واتساب المتجر بصيغة دولية بدون + أو مسافات.
4) ارفع مجلد droxilo_landing_page كاملاً إلى الاستضافة.

ملاحظة:
الصور المستخدمة هي الصور التي تم تزويدها في المحادثة.
